<h1 align="center">Portfolio UI Dashboard</h1>

## Getting Started

1. Install dependencies

```bash
yarn
```

2. Start development server

```bash
yarn run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Packages Used

- Tailwind / Tailwind Forms
- Fontsource (Easy Google Fonts Integration)
- MUI icons (SVG Icons)
- ChakraUI

### Other Recommended Packages

- Forms: React Hooks Forms, Formik
- Form Validation: Yup, Zod
- UI: Headless UI, Radix UI
- Alerts: React Hot Toast
- Data Fetching: Axios, React Query, Redux Toolkit
- Utility: Lodash, Date-fns, Moment
