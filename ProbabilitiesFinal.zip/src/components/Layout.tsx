import { Box } from '@mui/material'
import React, { useState } from 'react'
import SideBar from './sidebar/SideBar'
import TopBar from './topbar/TopBar'

type childProps = {
    children : JSX.Element
}

const Layout = ({children} : childProps) => {
  return (
    <Box display="flex" width="100%" height="auto">
    <SideBar />
    <TopBar>
        {children}
    </TopBar>
  </Box>
  )
}

export default Layout