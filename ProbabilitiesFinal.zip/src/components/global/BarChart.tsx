import { Box, Button, TextField } from "@mui/material";
import { ResponsiveBar } from '@nivo/bar'
import Header from './Header'
import { useTheme } from '@emotion/react';
import { tokens } from "@/utils/theme";
import { mockBarData } from "@/utils/mockData";
import ResponsiveBarChart from "./ResponsiveBarChart";

const BarChart = ({ isDashboard = false }) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <Box m="20px">
    <Box display="flex" justifyContent="space-between" alignItems="center">
        <Header title='Bar Chart' subtitle='Simple Bar Chart' />
    </Box>
    <Box m="5px 0" height="60vh">
      <ResponsiveBarChart />
    </Box>
    </Box>
  )
}

export default BarChart