import { Box, List, ListItem, ListItemText, Typography } from "@mui/material";
import Header from "./Header";
import { useTheme } from "@emotion/react";
import { tokens } from "@/utils/theme";
import { dateFormatter, dateAdvancedFormatter } from "@/utils/helper";
import { useState } from "react";
import { formatDate } from "@fullcalendar/core";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";
import listPlugin from "@fullcalendar/list";

const Calendar = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [currentEvents, setCurrentEvents] = useState([]);

  const handleDateClick = (selected : any) => {
    const title = prompt("Please enter a new title for your event");
    const calendarApi = selected.view.calendar;
    calendarApi.unselect()
    if(title){
      calendarApi.addEvent({
        id: `${selected.dateStr}-${title}`,
        title,
        start: selected.startStr,
        end: selected.endStr,
        allDay: selected.allDay,
      });
    }
  }

  const handleEventClick = (selected : any) => {
    if (
      window.confirm(
        `Are you sure you want to delete the event '${selected.event.title}'`
      )
    ) {
      selected.event.remove();
    }
  }
  const date = new Date()

  return (
    <Box m="10px">
      <Box display="flex" justifyContent="space-between" alignItems="center">
        <Header title="Calendar" subtitle="Welcome to Admins Dashboard" />
      </Box>
      <Box display="flex" justifyContent="space-between">
        {/* EVENTS TAB */}
        <Box
          bgcolor={colors.primary[400]}
          padding="15px"
          flex="1 1 20%"
          borderRadius="4px"
        >
          <Typography variant="h5">Events</Typography>
          {currentEvents.map((event : any) => (
            <ListItem
              key={event.id}
              sx={{
                bgcolor: colors.greenAccent[500],
                margin: "10px 0",
                borderRadius: "2px",
              }}
            >
              <ListItemText
                primary={event.title}
                secondary={
                  <Typography>
                    {formatDate(event.start, {
                      year: "numeric",
                      month: "short",
                      day: "numeric",
                    })}
                  </Typography>
                }
              />
            </ListItem>
          ))}
        </Box>
        {/* CALENDAR */}
        <Box ml="15px" flex="1 1 100%">
          <FullCalendar
            height="70vh"
            plugins={[
              dayGridPlugin,
              interactionPlugin,
              timeGridPlugin,
              listPlugin,
            ]}
            headerToolbar={{
              left: "prev,next today",
              center: "title",
              right: "dayGridMonth,timeGridWeek,timeGridDay,listMonth"
            }}
            initialView="dayGridMonth"
            editable={true}
            selectable={true}
            selectMirror={true}
            dayMaxEvents={true}
            select={handleDateClick}
            eventClick={handleEventClick}
            eventsSet={(events : any) => setCurrentEvents(events)}
            initialEvents={[
              {
                id: "1234",
                title: "All-day event",
                date: dateFormatter(date),
              },
              {
                id: "4321",
                title: "Timed event",
                date:  dateAdvancedFormatter({ 
                  date:date,
                  advancedDay: 3
                }),
              },
            ]}
          />
        </Box>
      </Box>
    </Box>
  );
};

export default Calendar;
