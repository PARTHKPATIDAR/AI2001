import { Box } from '@mui/system'
import Header from './Header'
import { useTheme } from '@emotion/react';
import { tokens } from "@/utils/theme";
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import { mockDataContacts } from '@/utils/mockData';
import { Typography } from '@mui/material';

const Contacts = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const columns = [
    { field: "id", headerName: "ID" ,flex: 0.5},
    { field: "registrarId", headerName: "Registrar Id"},
    {
      field: "name",
      headerName: "Name",
      flex: 1,
      cellClassName: "name-column--cell",
    },
    {
      field: "email",
      headerName: "Email",
    },
    {
      field: "phone",
      headerName: "Phone Number",
    },
    {
      field: "age",
      headerName: "Age",
      type: "number",
      headerAlign: "left",
      align: "left",
    },
    {
      field: "address",
      headerName: "Address",
      type: "string",
      headerAlign: "left",
      align: "left",
      flex:1,
    },
    {
      field: "city",
      headerName: "City",
      type: "string",
      headerAlign: "left",
      align: "left",
      flex:0.5,
    },
    {
      field: "zipCode",
      headerName: "Zip code",
      type: "string",
      headerAlign: "left",
      align: "left",
      flex:0.5,
    },
  ];
  return (
    <Box m="20px">
    <Box display="flex" justifyContent="space-between" alignItems="center">
        <Header title='Contacts' subtitle='List of Contacts for Future Reference' />
    </Box>
    <Box
       sx={{
        "& .MuiDataGrid-root": {
          border: "none",
        },
        "& .MuiDataGrid-cell": {
          borderBottom: "none",
        },
        "& .name-column--cell": {
          color: colors.greenAccent[300],
        },
        "& .MuiDataGrid-columnHeaders": {
          backgroundColor: colors.blueAccent[700],
          borderBottom: "none",
        },
        "& .MuiDataGrid-virtualScroller": {
          backgroundColor: colors.primary[400],
        },
        "& .MuiDataGrid-footerContainer": {
          borderTop: "none",
          backgroundColor: colors.blueAccent[700],
        },
        "& .MuiCheckbox-root": {
          color: `${colors.greenAccent[200]} !important`,
        },
        "& .MuiDataGrid-toolbarContainer .MuiButton-text": {
          color: `${colors.grey[100]} !important`,
        },
      }}
      m="10px 0" height="70vh">
      <DataGrid rows={mockDataContacts} columns={columns} components={{Toolbar: GridToolbar}}/>
    </Box>
    </Box>
  )
}

export default Contacts