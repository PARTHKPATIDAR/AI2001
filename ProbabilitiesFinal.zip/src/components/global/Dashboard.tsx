import { Box, Button, IconButton, Typography } from "@mui/material";
import Header from './Header'
import { useTheme } from '@emotion/react';
import { tokens } from "@/utils/theme";
import DownLoadIcon from '@mui/icons-material/DownloadOutlined';
import EmailIcon from "@mui/icons-material/Email";
import PointOfSaleIcon from "@mui/icons-material/PointOfSale";
import PersonAddIcon from "@mui/icons-material/PersonAdd";
import TrafficIcon from "@mui/icons-material/Traffic";
import StatBox from "./StatBox";
import ResponsiveLineChart from "./ResponsiveLineChart";
import { mockTransactions } from "@/utils/mockData";
import ProgressCircle from "./ProgressCircular";
import ResponsiveBarChart from "./ResponsiveBarChart";
import ResponsiveGeoMap from "./ResponsiveGeoMap";

const Dashboard = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return (
    <Box m="5px">
    <Box display="flex" justifyContent="space-between" alignItems="start" height="max-content">
        <Header title='Dashboard' subtitle='Welcome to Admins Dashboard' />
      <Button
        sx={{
          bgcolor: `${colors.blueAccent[700]} !important`,
          color: `${colors.grey[100]} !important`,
          fontSize: "14px",
          fontWeight: "bold",
          padding: "8px 15px"
        }}
      >
        <DownLoadIcon sx={{mr : "10px"}} />
        Download Reports
      </Button>
    </Box>
    {/* GRIDS & CHARTS */}
      <Box 
        display="grid"
        gridTemplateColumns="repeat(12,1fr)"
        gridAutoRows="100px"
        gap="5px"
      >
        {/* ROW 1 */}
        <Box 
          gridColumn="span 3" 
          bgcolor={colors.primary[400]} 
          display="flex" 
          alignItems="center" 
          justifyContent="center"
        >
          <StatBox
            title="15,580"
            subTitle="Emails Sent"
            progress="0.75"
            increase="+13%"
            icon={
            <EmailIcon 
              sx={{
                  color: colors.greenAccent[600],
                  fontSize: "22px",
                  }} 
            />} 
          />
        </Box>
        <Box 
          gridColumn="span 3" 
          bgcolor={colors.primary[400]} 
          display="flex" 
          alignItems="center" 
          justifyContent="center"
        >
          <StatBox
            title="456,236"
            subTitle="Sales Obtained"
            progress="0.5"
            increase="+21%"
            icon={
            <PointOfSaleIcon 
              sx={{
                  color: colors.greenAccent[600],
                  fontSize: "22px",
                  }} 
            />} 
          />
        </Box>
        <Box 
          gridColumn="span 3" 
          bgcolor={colors.primary[400]} 
          display="flex" 
          alignItems="center" 
          justifyContent="center"
        >
          <StatBox
            title="32,836"
            subTitle="New Clients"
            progress="0.30"
            increase="+5%"
            icon={
            <PersonAddIcon 
              sx={{
                  color: colors.greenAccent[600],
                  fontSize: "22px",
                  }} 
            />} 
          />
        </Box>
        <Box 
          gridColumn="span 3" 
          bgcolor={colors.primary[400]} 
          display="flex" 
          alignItems="center" 
          justifyContent="center"
        >
          <StatBox
            title="2,132,836"
            subTitle="Traffic Inbound"
            progress="0.80"
            increase="+48%"
            icon={
            <TrafficIcon 
              sx={{
                  color: colors.greenAccent[600],
                  fontSize: "22px",
                  }} 
            />} 
          />
        </Box>
        {/* ROW 2 */}
        <Box
         gridColumn="span 8" 
         gridRow="span 2" 
         bgcolor={colors.primary[400]}
        //  height="max-content" 
        >
          <Box mt="10px" p="0 30px" display="flex" justifyContent="space-between" alignItems="center">
          <Box display="flex" gap="10px" justifyContent="space-between" alignItems="center">
                  <Typography variant="h6" fontWeight="600" color={colors.grey[100]}>
                    Revenue Generated
                  </Typography>
                  <Typography variant="h5" fontWeight="500" color={colors.greenAccent[500]} border={`1px solid ${colors.greenAccent[500]}`} p="5px 15px" borderRadius="4px">
                    $69,342,56
                  </Typography>
          </Box>
          <Box>
            <IconButton>
              <DownLoadIcon 
              sx={{
                fontSize: "22px",
                color : colors.greenAccent[500],
              }}/>
            </IconButton>
          </Box>
          </Box>
          <Box height="230px" marginTop="-50px">
            <ResponsiveLineChart />
          </Box>
        </Box>
        <Box
         gridColumn="span 4" 
         gridRow="span 2" 
         bgcolor={colors.primary[400]} 
         sx={{
          overflowY:"scroll",
          "::-webkit-scrollbar" :{
            width: "4px"
          },
          "::-webkit-scrollbar-track" :{
            background: "transparent"
          },
          "::-webkit-scrollbar-thumb" :{
            background: "transparent"
          },
          ":hover": {
          "::-webkit-scrollbar-track" :{
            background: "#e0e0e0"
          }, "::-webkit-scrollbar-thumb" :{
            background: colors.greenAccent[500]
          }
          },
         }}
        >
         <Box display="flex" justifyContent="space-between" alignItems="center" borderBottom={`4px solid ${colors.primary[500]}`} color={colors.grey[100]} p="15px">
                  <Typography variant="h5" fontWeight="600" color={colors.grey[100]}>
                    Recent Transaction
                  </Typography>
          </Box>
          {mockTransactions.map((transaction, i) => (
            <Box 
              key={`${transaction.txId}-${i}`}
              display="flex"
              justifyContent="space-between"
              alignItems="center"
              borderBottom={`4px solid ${colors.primary[500]}`}
              p="15px"
            >
              <Box>
                <Typography variant="h5" fontWeight="600" color={colors.greenAccent[500]}>
                    {transaction.txId}
                </Typography>
              </Box>
              <Box color={colors.grey[100]}>{transaction.date}</Box>
              <Box bgcolor={colors.greenAccent[500]} p="5px 10px" borderRadius="4px" color={colors.grey[100]}>${transaction.cost}</Box>
            </Box>
          ))}
        </Box>
        {/* ROW 3 */}
        <Box
         gridColumn="span 4" 
         gridRow="span 2" 
         bgcolor={colors.primary[400]}
         p="15px"
        >
            <Typography variant="h5" fontWeight="600" color={colors.grey[100]}>
              Campaign
            </Typography>  
            <Box 
              display="flex"
              flexDirection="column"
              justifyContent="space-between"
              alignItems="center"
              mt="10px"
            >
              <ProgressCircle size="100" /> 
              <Typography variant="h5" fontWeight="600" color={colors.greenAccent[500]} mt="15px">
                $38,564 revenue generated
              </Typography>  
              <Typography>
                Includes extra misc expenditures and costs
              </Typography>  
            </Box>
        </Box>
        <Box
         gridColumn="span 4" 
         gridRow="span 2" 
         bgcolor={colors.primary[400]}
         p="15px"
         overflow="hidden"
        >
            <Typography variant="h5" fontWeight="600" color={colors.grey[100]}>
              Sales Quantity
            </Typography>  
            <Box 
              display="flex"
              flexDirection="column"
              justifyContent="space-between"
              alignItems="center"
              mt="10px"
              height="235px"
              marginTop="-40px"
            >
              <ResponsiveBarChart />
            </Box>
        </Box>
        <Box
         gridColumn="span 4" 
         gridRow="span 2" 
         bgcolor={colors.primary[400]}
         p="15px"
         overflow="hidden"
        >
            <Typography variant="h5" fontWeight="600" color={colors.grey[100]}>
              Geography Based Traffic
            </Typography>  
            <Box 
              display="flex"
              flexDirection="column"
              justifyContent="space-between"
              alignItems="center"
              mt="10px"
              height="235px"
              marginTop="-25px"
            >
              <ResponsiveGeoMap />
            </Box>
        </Box>
      </Box>
    </Box>
  )
}

export default Dashboard