import { Box, Button, TextField } from "@mui/material";
import Header from './Header'
import { ResponsiveChoropleth } from '@nivo/geo'
import { useTheme } from '@emotion/react';
import { tokens } from "@/utils/theme";
import { mockGeographyData } from '@/utils/mockData';
import { geoFeatures } from "@/utils/mockGeoFeatures";

const GeoGraphy = ({ isDashboard = false }) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <Box m="20px">
    <Box display="flex" justifyContent="space-between" alignItems="center">
        <Header title='Geography Map' subtitle='Simple Geography chart' />
    </Box>
    <Box m="5px 0" height="65vh" border={`1px solid ${colors.grey[100]}`} borderRadius="4px">
    <ResponsiveChoropleth
        data={mockGeographyData}
        features={geoFeatures.features}
        margin={{ top: 0, right: 0, bottom: 0, left: 0 }}
        domain={[ 0, 1000000 ]}
        unknownColor="#666666"
        label="properties.name"
        valueFormat=".2s"
        projectionScale={isDashboard ? 40 : 150}
        projectionTranslation={isDashboard ? [0.49, 0.6] : [ 0.5, 0.5 ]}
        projectionRotation={[ 0, 0, 0 ]}
        borderWidth={1.5}
        borderColor="#ffffff"
        legends={!isDashboard ? 
            [{
                anchor: 'bottom-left',
                direction: 'column',
                justify: true,
                translateX: 20,
                translateY: -100,
                itemsSpacing: 0,
                itemWidth: 94,
                itemHeight: 18,
                itemDirection: 'left-to-right',
                itemTextColor: '#444444',
                itemOpacity: 0.85,
                symbolSize: 18,
                effects: [
                    {
                        on: 'hover',
                        style: {
                            itemTextColor: '#000000',
                            itemOpacity: 1
                        }
                    }
                ]
            }] : undefined
        }
    />
    </Box>
    </Box>
  )
}

export default GeoGraphy