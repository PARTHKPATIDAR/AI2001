import { Box } from '@mui/system'
import Header from './Header'
import { useTheme } from '@emotion/react';
import { tokens } from "@/utils/theme";
import { DataGrid, GridToolbar } from '@mui/x-data-grid';
import { mockDataInvoices } from '@/utils/mockData';
import { Typography } from '@mui/material';

const Invoices = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const columns = [
    { field: "id", headerName: "ID" ,flex: 0.5},
    {
      field: "name",
      headerName: "Name",
      flex: 1,
      cellClassName: "name-column--cell",
    },
    {
      field: "email",
      headerName: "Email",
      flex: 1,
    },
    {
      field: "phone",
      headerName: "Phone Number",
      flex: 1,
    },
    {
      field: "cost",
      headerName: "Cost",
      type: "string",
      headerAlign: "left",
      align: "left",
      flex: 1,
    },
    {
      field: "date",
      headerName: "Date",
      type: "string",
      headerAlign: "left",
      align: "left",
      flex:1,
    },
  ];
  return (
    <Box m="20px">
    <Box display="flex" justifyContent="space-between" alignItems="center">
        <Header title='Invoices' subtitle='List of Invoices Balances' />
    </Box>
    <Box
       sx={{
        "& .MuiDataGrid-root": {
          border: "none",
        },
        "& .MuiDataGrid-cell": {
          borderBottom: "none",
        },
        "& .name-column--cell": {
          color: colors.greenAccent[300],
        },
        "& .MuiDataGrid-columnHeaders": {
          backgroundColor: colors.blueAccent[700],
          borderBottom: "none",
        },
        "& .MuiDataGrid-virtualScroller": {
          backgroundColor: colors.primary[400],
        },
        "& .MuiDataGrid-footerContainer": {
          borderTop: "none",
          backgroundColor: colors.blueAccent[700],
        },
        "& .MuiCheckbox-root": {
          color: `${colors.greenAccent[200]} !important`,
        },
        "& .MuiDataGrid-toolbarContainer .MuiButton-text": {
          color: `${colors.grey[100]} !important`,
        },
      }}
      m="10px 0" height="70vh">
      <DataGrid rows={mockDataInvoices} columns={columns} checkboxSelection/>
    </Box>
    </Box>
  )
}

export default Invoices