import { Box, Button, TextField } from "@mui/material";
import Header from './Header'
import { useTheme } from '@emotion/react';
import { tokens } from "@/utils/theme";
import ResponsiveLineChart from "./ResponsiveLineChart";


const LineChart = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  return (
    <Box m="20px">
    <Box display="flex" justifyContent="space-between" alignItems="center">
        <Header title='Line Chart' subtitle='Welcome to Admins Dashboard' />
    </Box>
    <Box m="5px 0" height="60vh">
      <ResponsiveLineChart />
    </Box>
    </Box>
  )
}

export default LineChart