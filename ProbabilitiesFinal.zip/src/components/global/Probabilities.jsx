import React, { useCallback, useEffect, useState } from "react";
import Header from "./Header";
import { useTheme } from "@emotion/react";
import { tokens } from "@/utils/theme";
import { Box, Button, TextField, Typography } from "@mui/material";
import { Accordion } from "@mui/material";
import { AccordionDetails } from "@mui/material";
import { AccordionSummary } from "@mui/material";
import ExpandMore from "@mui/icons-material/ExpandMore";

const Probabilities = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);

  const [diagnosisVal, setDiagnosisVal] = useState({
    coldS: 3,
    flueS: 5,
    coldSn: 7,
    flueSn: 9,
  });
  //   const [coldS, setColdS] = useState(3);
  //   const [flueS, setFlueS] = useState(5);
  //   const [coldSn, setColdSn] = useState(7);
  //   const [flueSn, setFlueSn] = useState(9);

  const handleColdSn = useCallback(
    (e) => {
      setDiagnosisVal({ ...diagnosisVal, coldSn: e.target.value });
    },
    [diagnosisVal]
  );
  const handleFlueSn = useCallback(
    (e) => {
      setDiagnosisVal({ ...diagnosisVal, flueSn: e.target.value });
    },
    [diagnosisVal]
  );

  const handleColdS = useCallback(
    (e) => {
      setDiagnosisVal({ ...diagnosisVal, coldS: e.target.value });
    },
    [diagnosisVal]
  );

  const handleFlueS = useCallback(
    (e) => {
      setDiagnosisVal({ ...diagnosisVal, flueS: e.target.value });
    },
    [diagnosisVal]
  );
  return (
    <Box m="20px">
      <Box display="flex" justifyContent="space-between" alignItems="center">
        <Header title="PROBABILITIES" subtitle="FLUE AND COLD PROBABILITIES" />
      </Box>
      <Box
        m="25px 20px"
        height="65vh"
        display="flex"
        // flexDirection="column"
        sx={{
          overflowY: "scroll",
          "::-webkit-scrollbar": {
            width: "4px",
          },
          "::-webkit-scrollbar-track": {
            background: "transparent",
          },
          "::-webkit-scrollbar-thumb": {
            background: "transparent",
          },
          ":hover": {
            "::-webkit-scrollbar-track": {
              background: "#e0e0e0",
            },
            "::-webkit-scrollbar-thumb": {
              background: colors.greenAccent[500],
            },
          },
        }}
      >
        {/* <div className="flex justify-start items-center">
          <div className="flex justify-start items-center">
            <div className="flex">
              <div>Symptoms</div>
            </div>
            <div className="flex flex-col">
              <div>Symptoms</div>
              <div>Symptoms</div>
            </div>
          </div>
          <div className="flex flex-col justify-start items-center">
            <div className="flex">
              <div>Symptoms</div>
            </div>
            <div className="flex">
              <div>Symptoms</div>
              <div>Symptoms</div>
            </div>
            <div className="flex">
              <div>Symptoms</div>
              <div>Symptoms</div>
            </div>
            <div className="flex">
              <div>Symptoms</div>
              <div>Symptoms</div>
            </div>
            <div className="flex">
              <div>Symptoms</div>
              <div>Symptoms</div>
            </div>
          </div>
          <div className="flex flex-col justify-start items-center">
            <div className="flex">
              <div>Symptoms</div>
            </div>
            <div className="flex">
              <div>Symptoms</div>
            </div>
            <div className="flex">
              <div>Symptoms</div>
            </div>
          </div>
        </div> */}
        <div className="flex flex-col gap-5 py-10">
          <h1>Explanation</h1>
          <table className="border-collapse">
            <thead>
              <tr>
                <th className="px-4 py-2"></th>
                <th className="px-4 py-2"></th>
                <th className="border px-4 py-2" colspan="2">
                  Diagonosis
                </th>
                <th className="px-4 py-2"></th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="px-4 py-2"></td>
                <td className="px-4 py-2"></td>
                <td className="border px-4 py-2">Cold</td>
                <td className="border px-4 py-2">Flue</td>
                <td className="px-4 py-2"></td>
              </tr>
              <tr>
                <td rowSpan={2} className="border px-4 py-2">
                  Symptoms
                </td>
                <td className="border px-4 py-2">S</td>
                <td className="border px-4 py-2">P(S, Cold)</td>
                <td className="border px-4 py-2">P(S, Flu)</td>
                <td className="border px-4 py-2">P(S)</td>
              </tr>
              <tr>
                <td className="border px-4 py-2">SN</td>
                <td className="border px-4 py-2">P(NS, Cold)</td>
                <td className="border px-4 py-2">P(NS, Flu)</td>
                <td className="border px-4 py-2">P(NS)</td>
              </tr>
              <tr>
                <td className="px-4 py-2"></td>
                <td className="px-4 py-2"></td>
                <td className="border px-4 py-2">P(Cold)</td>
                <td className="border px-4 py-2">P(Flu)</td>
                <td className="px-4 py-2"></td>
              </tr>
            </tbody>
          </table>
          <h1>Contigency Table (Counts of Events)</h1>
          <table className="border-collapse">
            <thead>
              <tr>
                <th className="px-4 py-2"></th>
                <th className="px-4 py-2"></th>
                <th className="border px-4 py-2" colspan="2">
                  Diagonosis
                </th>
                <th className="px-4 py-2"></th>
              </tr>
            </thead>
            <tbody>
              {/* {data.map((item, index) => ( */}
              <tr>
                <td className="px-4 py-2"></td>
                <td className="px-4 py-2"></td>
                <td className="border px-4 py-2">Cold</td>
                <td className="border px-4 py-2">Flue</td>
                <td className="px-4 py-2"></td>
              </tr>
              <tr>
                <td rowSpan={2} className="border px-4 py-2">
                  Symptoms
                </td>
                <td className="border px-4 py-2">S</td>
                <td className="border px-4 py-2">
                  <input
                    className="bg-slate-900 max-w-[70px] border py-0.5 px-1 rounded-sm"
                    onChange={(e) => handleColdS(e)}
                    value={diagnosisVal.coldS}
                  />
                </td>
                <td className="border px-4 py-2">
                  <input
                    className="bg-slate-900 max-w-[70px] border py-0.5 px-1 rounded-sm"
                    onChange={(e) => handleFlueS(e)}
                    value={diagnosisVal.flueS}
                  />
                </td>
                <td className="border px-4 py-2">
                  {Number(diagnosisVal.coldS) + Number(diagnosisVal.flueS)}
                </td>
              </tr>
              <tr>
                {/* <td className="border px-4 py-2">Symptoms</td> */}
                <td className="border px-4 py-2">SN</td>
                <td className="border px-4 py-2">
                  <input
                    className="bg-slate-900 max-w-[70px] border py-0.5 px-1 rounded-sm"
                    onChange={(e) => handleColdSn(e)}
                    value={diagnosisVal.coldSn}
                  />
                </td>
                <td className="border px-4 py-2">
                  <input
                    className="bg-slate-900 max-w-[70px] border py-0.5 px-1 rounded-sm"
                    onChange={(e) => handleFlueSn(e)}
                    value={diagnosisVal.flueSn}
                  />
                </td>
                <td className="border px-4 py-2">
                  {Number(diagnosisVal.coldSn) + Number(diagnosisVal.flueSn)}
                </td>
              </tr>
              <tr>
                <td className="px-4 py-2"></td>
                <td className="px-4 py-2"></td>
                <td className="border px-4 py-2">
                  {Number(diagnosisVal.coldS) + Number(diagnosisVal.coldSn)}
                </td>
                <td className="border px-4 py-2">
                  {Number(diagnosisVal.flueS) + Number(diagnosisVal.flueSn)}
                </td>
                <td className="border px-4 py-2">
                  {Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn)}
                </td>
              </tr>
              {/* ))} */}
            </tbody>
          </table>
          <h1>Joint and Marginal Probabilities</h1>
          <table className="border-collapse">
            <thead>
              <tr>
                <th className="px-4 py-2"></th>
                <th className="px-4 py-2"></th>
                <th className="border px-4 py-2" colspan="2">
                  Diagonosis
                </th>
                <th className="px-4 py-2"></th>
              </tr>
            </thead>
            <tbody>
              {/* {data.map((item, index) => ( */}
              <tr>
                <td className="px-4 py-2"></td>
                <td className="px-4 py-2"></td>
                <td className="border px-4 py-2">Cold</td>
                <td className="border px-4 py-2">Flue</td>
                <td className="px-4 py-2"></td>
              </tr>
              <tr>
                <td rowSpan={2} className="border px-4 py-2">
                  Symptoms
                </td>
                <td className="border px-4 py-2">S</td>
                <td className="border px-4 py-2">
                  {/* <input
                    className="bg-slate-900 max-w-[70px]"
                    onChange={(e) => handleColdS(e)}
                    value={diagnosisVal.coldS}
                  /> */}
                  {Number(diagnosisVal.coldS) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn))}
                </td>
                <td className="border px-4 py-2">
                  {/* <input
                    className="bg-slate-900 max-w-[70px]"
                    onChange={(e) => handleFlueS(e)}
                    value={diagnosisVal.flueS}
                  /> */}
                  {Number(diagnosisVal.flueS) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn))}
                </td>
                <td className="border px-4 py-2">
                  {(Number(diagnosisVal.coldS) + Number(diagnosisVal.flueS)) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn))}
                </td>
              </tr>
              <tr>
                {/* <td className="border px-4 py-2">Symptoms</td> */}
                <td className="border px-4 py-2">SN</td>
                <td className="border px-4 py-2">
                  {/* <input
                    className="bg-slate-900 max-w-[70px]"
                    onChange={(e) => handleColdSn(e)}
                    value={diagnosisVal.coldSn}
                  /> */}
                  {Number(diagnosisVal.coldSn) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn))}
                </td>
                <td className="border px-4 py-2">
                  {/* <input
                    className="bg-slate-900 max-w-[70px]"
                    onChange={(e) => handleFlueSn(e)}
                    value={diagnosisVal.flueSn}
                  /> */}
                  {Number(diagnosisVal.flueSn) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn))}
                </td>
                <td className="border px-4 py-2">
                  {(Number(diagnosisVal.coldSn) + Number(diagnosisVal.flueSn)) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn))}
                </td>
              </tr>
              <tr>
                <td className="px-4 py-2"></td>
                <td className="px-4 py-2"></td>
                <td className="border px-4 py-2">
                  {(Number(diagnosisVal.coldS) + Number(diagnosisVal.coldSn)) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn))}
                </td>
                <td className="border px-4 py-2">
                  {(Number(diagnosisVal.flueS) + Number(diagnosisVal.flueSn)) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn))}
                </td>
                <td className="border px-4 py-2">
                  {(Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn)) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn))}
                </td>
              </tr>
              {/* ))} */}
            </tbody>
          </table>
          <h1>Likelihood, Posterior & (Likelihood X Prior) / Total Evidence</h1>
          <table className="border-collapse">
            <tr>
              <th className="border px-4 py-2" colSpan={4}>
                {"Likelihood"}
              </th>
            </tr>
            <tr>
              <td className="border px-4 py-2" rowspan="2">
                P(S | Cold)
              </td>
              <td className="border px-4 py-2">P(S, Cold)</td>
              <td className="border px-4 py-2">
                {" "}
                {Number(diagnosisVal.coldS) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              <td className="border px-4 py-2" rowspan="2">
                {Number(diagnosisVal.coldS) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn)) /
                  ((Number(diagnosisVal.coldS) + Number(diagnosisVal.coldSn)) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn)))}
              </td>
            </tr>
            <tr>
              <td className="border px-4 py-2">P(Cold)</td>
              <td className="border px-4 py-2">
                {(Number(diagnosisVal.coldS) + Number(diagnosisVal.coldSn)) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              {/* <td className="border px-4 py-2">$12</td> */}
            </tr>

            <tr>
              <td className="border px-4 py-2" rowspan="2">
                P(NS | Cold)
              </td>
              <td className="border px-4 py-2">P(NS, Cold)</td>
              <td className="border px-4 py-2">
                {" "}
                {Number(diagnosisVal.coldSn) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              <td className="border px-4 py-2" rowspan="2">
                {Number(diagnosisVal.coldSn) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn)) /
                  ((Number(diagnosisVal.coldS) + Number(diagnosisVal.coldSn)) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn)))}
              </td>
            </tr>
            <tr>
              <td className="border px-4 py-2">P(Cold)</td>
              <td className="border px-4 py-2">
                {(Number(diagnosisVal.coldS) + Number(diagnosisVal.coldSn)) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              {/* <td className="border px-4 py-2">$12</td> */}
            </tr>

            <tr>
              <td className="border px-4 py-2" rowspan="2">
                P(S | Flu)
              </td>
              <td className="border px-4 py-2">P(S, Flu)</td>
              <td className="border px-4 py-2">
                {" "}
                {Number(diagnosisVal.flueS) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              <td className="border px-4 py-2" rowspan="2">
                {Number(diagnosisVal.flueS) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn)) /
                  ((Number(diagnosisVal.flueS) + Number(diagnosisVal.flueSn)) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn)))}
              </td>
            </tr>
            <tr>
              <td className="border px-4 py-2">P(Flu)</td>
              <td className="border px-4 py-2">
                {(Number(diagnosisVal.flueS) + Number(diagnosisVal.flueSn)) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              {/* <td className="border px-4 py-2">$12</td> */}
            </tr>
            <tr>
              <td className="border px-4 py-2" rowspan="2">
                P(NS | Flu)
              </td>
              <td className="border px-4 py-2">P(NS | Flu)</td>
              <td className="border px-4 py-2">
                {" "}
                {Number(diagnosisVal.flueSn) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              <td className="border px-4 py-2" rowspan="2">
                {Number(diagnosisVal.flueSn) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn)) /
                  ((Number(diagnosisVal.flueS) + Number(diagnosisVal.flueSn)) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn)))}
              </td>
            </tr>
            <tr>
              <td className="border px-4 py-2">P(Flu)</td>
              <td className="border px-4 py-2">
                {(Number(diagnosisVal.flueS) + Number(diagnosisVal.flueSn)) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              {/* <td className="border px-4 py-2">$12</td> */}
            </tr>
            <tr>
              <th className="border px-4 py-2" colSpan={4}>
                {"P( X | Y ) --> Likelihood"}
              </th>
            </tr>
          </table>
          <table className="border-collapse">
            <tr>
              <th className="border px-4 py-2" colSpan={4}>
                {"Posterior"}
              </th>
              <th className="border px-4 py-2" colSpan={4}>
                {"(Likelihood X Prior) / Total Evidence"}
              </th>
            </tr>
            <tr>
              <td className="border px-4 py-2" rowspan="2">
                P(S | Cold)
              </td>
              <td className="border px-4 py-2">P(S, Cold)</td>
              <td className="border px-4 py-2">
                {" "}
                {Number(diagnosisVal.coldS) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              <td className="border px-4 py-2" rowspan="2">
                {Number(diagnosisVal.coldS) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn)) /
                  ((Number(diagnosisVal.coldS) + Number(diagnosisVal.flueS)) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn)))}
              </td>
              <td className="border px-4 py-2">P(S | Cold) x P(Cold)</td>
              <td className="border px-4 py-2">
                {" "}
                {Number(diagnosisVal.coldS) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              <td className="border px-4 py-2" rowspan="2">
                {Number(diagnosisVal.coldS) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn)) /
                  ((Number(diagnosisVal.coldS) + Number(diagnosisVal.flueS)) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn)))}
              </td>
            </tr>
            <tr>
              <td className="border px-4 py-2">P(S)</td>
              <td className="border px-4 py-2">
                {(Number(diagnosisVal.coldS) + Number(diagnosisVal.flueS)) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              <td className="border px-4 py-2">P(S)</td>
              <td className="border px-4 py-2">
                {(Number(diagnosisVal.coldS) + Number(diagnosisVal.flueS)) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
            </tr>

            <tr>
              <td className="border px-4 py-2" rowspan="2">
                P(Cold | NS)
              </td>
              <td className="border px-4 py-2">P(NS, Cold)</td>
              <td className="border px-4 py-2">
                {" "}
                {Number(diagnosisVal.coldS) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              <td className="border px-4 py-2" rowspan="2">
                {Number(diagnosisVal.coldS) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn)) /
                  ((Number(diagnosisVal.coldSn) + Number(diagnosisVal.flueSn)) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn)))}
              </td>
              <td className="border px-4 py-2">P(NS | Gold) x P(Cold)</td>
              <td className="border px-4 py-2">
                {" "}
                {Number(diagnosisVal.coldSn) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              <td className="border px-4 py-2" rowspan="2">
                {Number(diagnosisVal.coldS) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn)) /
                  ((Number(diagnosisVal.coldSn) + Number(diagnosisVal.flueSn)) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn)))}
              </td>
              <td className="border px-10 py-2" rowspan="2">
                {(Number(diagnosisVal.flueS) +
                  Number(diagnosisVal.flueSn) +
                  Number(diagnosisVal.coldS) +
                  Number(diagnosisVal.coldSn)) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
            </tr>
            <tr>
              <td className="border px-4 py-2">P(NS)</td>
              <td className="border px-4 py-2">
                {(Number(diagnosisVal.coldSn) + Number(diagnosisVal.flueSn)) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              <td className="border px-4 py-2">P(NS)</td>
              <td className="border px-4 py-2">
                {(Number(diagnosisVal.coldSn) + Number(diagnosisVal.flueSn)) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
            </tr>

            <tr>
              <td className="border px-4 py-2" rowspan="2">
                P(Flue | S)
              </td>
              <td className="border px-4 py-2">P(S, Cold)</td>
              <td className="border px-4 py-2">
                {" "}
                {Number(diagnosisVal.coldS) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              <td className="border px-4 py-2" rowspan="2">
                {Number(diagnosisVal.flueS) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn)) /
                  ((Number(diagnosisVal.flueS) + Number(diagnosisVal.flueSn)) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn)))}
              </td>
              <td className="border px-4 py-2">P(S | Flu) x P(Flu)</td>
              <td className="border px-4 py-2">
                {" "}
                {Number(diagnosisVal.flueS) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              <td className="border px-4 py-2" rowspan="2">
                {Number(diagnosisVal.flueS) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn)) /
                  ((Number(diagnosisVal.flueS) + Number(diagnosisVal.flueSn)) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn)))}
              </td>
              <td className="border px-10 py-2" rowspan="2">
                {(Number(diagnosisVal.flueS) +
                  Number(diagnosisVal.flueSn) +
                  Number(diagnosisVal.coldS) +
                  Number(diagnosisVal.coldSn)) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
            </tr>
            <tr>
              <td className="border px-4 py-2">P(S)</td>
              <td className="border px-4 py-2">
                {(Number(diagnosisVal.coldSn) + Number(diagnosisVal.flueSn)) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              <td className="border px-4 py-2">P(S)</td>
              <td className="border px-4 py-2">
                {(Number(diagnosisVal.flueS) + Number(diagnosisVal.flueSn)) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              {/* <td className="border px-4 py-2">$12</td> */}
            </tr>
            <tr>
              <td className="border px-4 py-2" rowspan="2">
                P(Flue | NS)
              </td>
              <td className="border px-4 py-2">P(NS, Flue)</td>
              <td className="border px-4 py-2">
                {" "}
                {Number(diagnosisVal.flueSn) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              <td className="border px-4 py-2" rowspan="2">
                {Number(diagnosisVal.flueSn) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn)) /
                  ((Number(diagnosisVal.coldSn) + Number(diagnosisVal.flueSn)) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn)))}
              </td>
              <td className="border px-4 py-2">P(NS | Flu) x P(Flu)</td>
              <td className="border px-4 py-2">
                {" "}
                {Number(diagnosisVal.flueSn) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              <td className="border px-4 py-2" rowspan="2">
                {Number(diagnosisVal.flueSn) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn)) /
                  ((Number(diagnosisVal.coldSn) + Number(diagnosisVal.flueSn)) /
                    (Number(diagnosisVal.flueS) +
                      Number(diagnosisVal.flueSn) +
                      Number(diagnosisVal.coldS) +
                      Number(diagnosisVal.coldSn)))}
              </td>
            </tr>
            <tr>
              <td className="border px-4 py-2">P(NS)</td>
              <td className="border px-4 py-2">
                {(Number(diagnosisVal.coldSn) + Number(diagnosisVal.flueSn)) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              <td className="border px-4 py-2">P(NS)</td>
              <td className="border px-4 py-2">
                {(Number(diagnosisVal.coldSn) + Number(diagnosisVal.flueSn)) /
                  (Number(diagnosisVal.flueS) +
                    Number(diagnosisVal.flueSn) +
                    Number(diagnosisVal.coldS) +
                    Number(diagnosisVal.coldSn))}
              </td>
              {/* <td className="border px-4 py-2">$12</td> */}
            </tr>
            <tr>
              <th className="border px-4 py-2" colSpan={8}>
                {"P( X | Y ) --> Likelihood"}
              </th>
            </tr>
          </table>
        </div>
      </Box>
    </Box>
  );
};

export default Probabilities;
