import React, { useState } from 'react'
import { tokens } from "@/utils/theme";
import { useTheme } from '@emotion/react';
import { Box, IconButton, Typography } from '@mui/material';
import HomeIcon from '@mui/icons-material/HomeOutlined';
import PeopleIcon from '@mui/icons-material/PeopleOutlined';
import ContactsIcon from '@mui/icons-material/ContactsOutlined';
import ReceiptIcon from '@mui/icons-material/ReceiptOutlined';
import PersonIcon from '@mui/icons-material/PersonOutlined';
import CalendarTodayIcon from '@mui/icons-material/CalendarTodayOutlined';
import HelpIcon from '@mui/icons-material/HelpOutlined';
import BarChartIcon from '@mui/icons-material/BarChartOutlined';
import PieChartOutlineIcon from '@mui/icons-material/PieChartOutlineOutlined';
import TimelineIcon from '@mui/icons-material/TimelineOutlined';
import MenuIcon from '@mui/icons-material/MenuOutlined';
import MapIcon from '@mui/icons-material/MapOutlined';

const CustomSideBar = () => {
    const theme = useTheme();
    const colors = tokens(theme.palette.mode);
    const [selected, setSelected] = useState("Dashboard");
    const [isCollapsed, setIsCollapsed] = useState(false);
  return (
    <Box onClick={() => {setIsCollapsed(!isCollapsed)}}>
        <Box display="flex" flexDirection="column">
            <Box display="flex" flexDirection="column">
                <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                ml="15px"
                width="100%"
                >
                <Typography variant="h3" color={colors.grey[100]}>
                    ADMINIS
                </Typography>
                <IconButton onClick={() => {setIsCollapsed(!isCollapsed)}}>
                    <MenuIcon />
                </IconButton>
                </Box>
                <Box display="flex">

                </Box>
            </Box>
        </Box>
    </Box>
  )
}

export default CustomSideBar