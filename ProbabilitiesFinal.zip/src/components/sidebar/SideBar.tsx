import Image from "next/image";
import { useState } from "react";
import { useTheme } from "@emotion/react";
import { Box } from "@mui/system";
import { Sidebar, Menu, MenuItem, useProSidebar } from "react-pro-sidebar";
import { tokens } from "@/utils/theme";
import HomeIcon from "@mui/icons-material/HomeOutlined";
import PeopleIcon from "@mui/icons-material/PeopleOutlined";
import ContactsIcon from "@mui/icons-material/ContactsOutlined";
import ReceiptIcon from "@mui/icons-material/ReceiptOutlined";
import PersonIcon from "@mui/icons-material/PersonOutlined";
import CalendarTodayIcon from "@mui/icons-material/CalendarTodayOutlined";
import HelpIcon from "@mui/icons-material/HelpOutlined";
import BarChartIcon from "@mui/icons-material/BarChartOutlined";
import PieChartOutlineIcon from "@mui/icons-material/PieChartOutlineOutlined";
import TimelineIcon from "@mui/icons-material/TimelineOutlined";
import MenuIcon from "@mui/icons-material/MenuOutlined";
import CalculateIcon from "@mui/icons-material/Calculate";
import MapIcon from "@mui/icons-material/MapOutlined";
import proPic from "../../assets/images/user1.png";
import { IconButton, Typography } from "@mui/material";
import Link from "next/link";
import { useRouter } from "next/router";

const Item = ({ title, icon, link }: any) => {
  const theme = useTheme();
  const router = useRouter();
  const colors = tokens(theme.palette.mode);

  return (
    <Link href={link}>
      <Box>
        <MenuItem
          active={router.asPath === link}
          style={{
            color: colors.grey[100],
            fontSize: "6px",
          }}
          // onClick={() => setSelected(title)}
          icon={icon}
        >
          <Typography sx={{ fontSize: "12px" }}>{title}</Typography>
          {/* <Link to={to} /> */}
        </MenuItem>
      </Box>
    </Link>
  );
};

const SideBar = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const { collapseSidebar, toggleSidebar, collapsed, toggled, broken, rtl } =
    useProSidebar();
  const [isCollapsed, setIsCollapsed] = useState(true);

  return (
    <Box
      sx={{
        "& .ps-sidebar-container": {
          background: `${colors.primary[400]} !important`,
        },
        "& .ps-sidebar-icon-wrapper": {
          backgroundColor: "transparent !important",
        },
        "& .ps-sidebar-inner-item": {
          padding: "5px 35px 5px 20px !important",
        },
        "& .ps-menuitem:hover": {
          color: "#868dfb !important",
        },
        "& .ps-active": {
          color: "#6870fa !important",
        },
        "& .ps-menu-button": {
          height: "35px !important",
        },
        "& .ps-sidebar-root": {
          height: "100vh !important",
          "& ::-webkit-scrollbar": {
            width: "3px;",
          },
        },
        "& .ps-menu-button:hover": {
          color: "#868dfb !important",
        },
      }}
    >
      <Sidebar>
        <Menu>
          {/* LOGO AND MENU ICON */}
          {collapsed && (
            <MenuItem
              icon={collapsed && <MenuIcon />}
              style={{
                margin: "10px 0 20px 0",
                color: colors.grey[100],
              }}
              onClick={() => collapseSidebar(!collapsed)}
            ></MenuItem>
          )}
          {!collapsed && (
            <Box
              display="flex"
              justifyContent="space-between"
              alignItems="center"
              p="0 15px"
              sx={{
                ":hover": {
                  bgcolor: "transparent !important",
                },
                margin: "10px 0 20px 0",
              }}
            >
              <Typography variant="h3" color={colors.grey[100]}>
                ADMIN
              </Typography>
              <IconButton onClick={() => collapseSidebar(!collapsed)}>
                <MenuIcon />
              </IconButton>
            </Box>
          )}
          {/* </MenuItem> */}

          {!collapsed && (
            <Box mb="5px">
              <Box display="flex" justifyContent="center" alignItems="center">
                <Image
                  alt="profile-user"
                  width={80}
                  height={80}
                  src={proPic}
                  className="cursor-pointer rounded-full"
                  // style={{ cursor: "pointer", borderRadius: "50%" }}
                />
              </Box>
              <Box textAlign="center">
                <Typography
                  variant="h4"
                  color={colors.grey[100]}
                  fontWeight="bold"
                  sx={{ m: "2px 0 0 0" }}
                >
                  MASTER ADMIN
                </Typography>
                <Typography variant="h6" color={colors.greenAccent[500]}>
                  SOFTWARE DEVELOPER
                </Typography>
              </Box>
            </Box>
          )}

          <Box>
            <Item
              title="Probabilities"
              link="/probabilities"
              icon={<CalculateIcon />}
            />
            <Item title="Dashboard" link="/" icon={<HomeIcon />} />

            <Typography
              variant="h6"
              color={colors.grey[300]}
              sx={{ m: "15px 0 5px 20px" }}
            >
              Data
            </Typography>
            <Item
              title="Manage Team"
              link="/team"
              icon={<PeopleIcon sx={{ fontSize: "20px" }} />}
            />
            <Item
              title="Contacts Information"
              link="/contacts"
              icon={<ContactsIcon sx={{ fontSize: "20px" }} />}
            />
            <Item
              title="Invoices Balances"
              link="/invoices"
              icon={<ReceiptIcon sx={{ fontSize: "20px" }} />}
            />

            <Typography
              variant="h6"
              color={colors.grey[300]}
              sx={{ m: "15px 0 5px 20px" }}
            >
              Pages
            </Typography>
            <Item
              title="Profile Form"
              link="/profile"
              icon={<PersonIcon sx={{ fontSize: "20px" }} />}
            />
            <Item
              title="Calendar"
              link="/calendar"
              icon={<CalendarTodayIcon sx={{ fontSize: "20px" }} />}
            />
            <Item
              title="FAQ Page"
              link="/faq"
              icon={<HelpIcon sx={{ fontSize: "20px" }} />}
            />

            <Typography
              variant="h6"
              color={colors.grey[300]}
              sx={{ m: "15px 0 5px 20px" }}
            >
              Charts
            </Typography>
            <Item
              title="Bar Chart"
              link="/bar"
              icon={<BarChartIcon sx={{ fontSize: "20px" }} />}
            />
            <Item
              title="Pie Chart"
              link="/pie"
              icon={<PieChartOutlineIcon sx={{ fontSize: "20px" }} />}
            />
            <Item
              title="Line Chart"
              link="/line"
              icon={<TimelineIcon sx={{ fontSize: "20px" }} />}
            />
            <Item
              title="Geography Chart"
              link="/geography"
              icon={<MapIcon sx={{ fontSize: "20px" }} />}
            />
          </Box>
        </Menu>
      </Sidebar>
    </Box>
  );
};

export default SideBar;
