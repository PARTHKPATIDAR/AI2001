import { ColorModeContext, tokens } from "@/utils/theme";
import { useTheme } from "@emotion/react";
import { Box, IconButton, InputBase } from "@mui/material";
import { Children, ReactComponentElement, useContext } from "react";
import SearchIcon from '@mui/icons-material/SearchOutlined';
import LightModeIcon from '@mui/icons-material/LightModeOutlined';
import NotificationsIcon from '@mui/icons-material/NotificationsOutlined';
import SettingsIcon from '@mui/icons-material/SettingsOutlined';
import DarkModeIcon from '@mui/icons-material/DarkModeOutlined';
import PersonIcon from '@mui/icons-material/PersonOutlined';
import { useRouter } from "next/router";

type childProps = {
  children : JSX.Element
}
const TopBar = ({children} : childProps) => {
    const theme = useTheme();
    const colors = tokens(theme.palette.mode);
    const colorMode = useContext(ColorModeContext);
    const {pathname} = useRouter()

  return (
    <Box display="flex" flexDirection="column" justifyContent="space-between" width="100%" height="max-content">
    <Box display="flex" justifyContent="space-between" p={pathname === "/" ? 0.5 : 1} width="100%" height="max-content">
      {/* SEARCH BAR */}
      <Box
        display="flex"
        bgcolor={colors.primary[400]}
        borderRadius="3px"
      >
        <InputBase sx={{ml: 2, flex: 1}} placeholder="Search"/>
        <IconButton type="button" sx={{p:1}}>
            <SearchIcon />
        </IconButton>
      </Box>
      {/* ICONS */}
      <Box
        display="flex"
      >
        <IconButton type="button" onClick={colorMode.toggleColorMode}>
            {theme.palette.mode === 'dark' ? 
                <DarkModeIcon />:
                <LightModeIcon/>
            }
        </IconButton>
        <IconButton type="button">
            <NotificationsIcon />
        </IconButton>
        <IconButton type="button">
            <SettingsIcon />
        </IconButton>
        <IconButton type="button">
            <PersonIcon />
        </IconButton>
      </Box>
    </Box>
    <Box>
      {children}
    </Box>
    </Box>
  );
}

export default TopBar