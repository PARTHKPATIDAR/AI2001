import '@/styles/globals.css'
import type { AppProps } from 'next/app'
import { ProSidebarProvider } from 'react-pro-sidebar';
import { CssBaseline, ThemeProvider } from "@mui/material";
import { ColorModeContext, useMode } from "../utils/theme";

export default function App({ Component, pageProps }: AppProps) {

  const [theme, colorMode] = useMode();
  return (
    <ColorModeContext.Provider value={colorMode}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <ProSidebarProvider>
        <Component {...pageProps} />
        </ProSidebarProvider>
      </ThemeProvider>
    </ColorModeContext.Provider>
  )
}
