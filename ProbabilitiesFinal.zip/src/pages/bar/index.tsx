import BarChart from '@/components/global/BarChart'
import Layout from '@/components/Layout'
import { Box } from '@mui/material'
import React, { useEffect } from 'react'

const bar = () => {
  useEffect(() => {
    document.title = "BAR CHART | PORTFOLIO"
  }, [])
  
  return (
    <Box display="flex" width="100%" height="auto">
        <Layout>
          <BarChart />
        </Layout>
      </Box>
  )
}

export default bar