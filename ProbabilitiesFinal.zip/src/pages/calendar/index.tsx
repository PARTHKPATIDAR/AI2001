import React, { useEffect } from 'react'
import Calendar from '@/components/global/Calendar'
import Layout from '@/components/Layout'
import { Box } from '@mui/material'

const calendar = () => {
  useEffect(() => {
    document.title = "CALENDAR EVENT | PORTFOLIO"
  }, [])
  return (
    <Box display="flex" width="100%" height="auto">
        <Layout>
          <Calendar />
        </Layout>
      </Box>
  )
}

export default calendar