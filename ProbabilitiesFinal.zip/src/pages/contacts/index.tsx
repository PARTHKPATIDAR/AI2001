import Contacts from '@/components/global/Contacts'
import Layout from '@/components/Layout'
import { Box } from '@mui/material'
import React, { useEffect } from 'react'

const contacts = () => {
  useEffect(() => {
    document.title = "CONTACT DETAILS | PORTFOLIO"
  }, [])
  return (
    <Box display="flex" width="100%" height="auto">
        <Layout>
          <Contacts />
        </Layout>
      </Box>
  )
}

export default contacts