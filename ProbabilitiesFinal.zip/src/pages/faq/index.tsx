import FAQ from '@/components/global/FAQ'
import Layout from '@/components/Layout'
import { Box } from '@mui/material'
import React, { useEffect } from 'react'

const faq = () => {
  useEffect(() => {
    document.title = "FAQs | PORTFOLIO"
  }, [])
  return (
    <Box display="flex" width="100%" height="auto">
        <Layout>
          <FAQ />
        </Layout>
      </Box>
  )
}

export default faq