import React, { useEffect } from 'react'
import GeoGraphy from '@/components/global/GeoGraphy'
import Layout from '@/components/Layout'
import { Box } from '@mui/material'

const geography = () => {
  useEffect(() => {
    document.title = "GEOGRAPHY MAP | PORTFOLIO"
  }, [])
  return (
    <Box display="flex" width="100%" height="auto">
        <Layout>
          <GeoGraphy />
        </Layout>
      </Box>
  )
}

export default geography