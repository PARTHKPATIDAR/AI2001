import React, { useEffect } from 'react'
import Invoices from '@/components/global/Invoices'
import Layout from '@/components/Layout'
import { Box } from '@mui/material'

const invoices = () => {
  useEffect(() => {
    document.title = "INVOICES | PORTFOLIO"
  }, [])
  return (
    <Box display="flex" width="100%" height="auto">
        <Layout>
          <Invoices />
        </Layout>
      </Box>
  )
}

export default invoices