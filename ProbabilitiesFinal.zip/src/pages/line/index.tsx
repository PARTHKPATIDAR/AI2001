import LineChart from '@/components/global/LineChart'
import Layout from '@/components/Layout'
import { Box } from '@mui/material'
import React, { useEffect } from 'react'

const line = () => {
  useEffect(() => {
    document.title = "LINE CHART | PORTFOLIO"
  }, [])
  return (
    <Box display="flex" width="100%" height="auto">
        <Layout>
          <LineChart />
        </Layout>
      </Box>
  )
}

export default line