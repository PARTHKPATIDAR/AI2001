import PieChart from '@/components/global/PieChart'
import Layout from '@/components/Layout'
import { Box } from '@mui/material'
import React, { useEffect } from 'react'

const pie = () => {
  useEffect(() => {
    document.title = "PIE CHART | PORTFOLIO"
  }, [])
  return (
    <Box display="flex" width="100%" height="auto">
        <Layout>
          <PieChart />
        </Layout>
      </Box>
  )
}

export default pie