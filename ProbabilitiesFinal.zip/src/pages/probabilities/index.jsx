import Probabilities from "../../components/global/Probabilities";
import Layout from "@/components/Layout";
import { Box } from "@mui/material";
import React, { useEffect } from "react";

const pie = () => {
  useEffect(() => {
    document.title = "PROBABILITIES | PORTFOLIO";
  }, []);

  return (
    <Box display="flex" width="100%" height="auto">
      <Layout>
        <Probabilities />
      </Layout>
    </Box>
  );
};

export default pie;
