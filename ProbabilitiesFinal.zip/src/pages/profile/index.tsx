import React, { useEffect } from 'react'
import Profile from '@/components/global/Profile'
import Layout from '@/components/Layout'
import { Box } from '@mui/material'

const profile = () => {
  useEffect(() => {
    document.title = "FORM | PORTFOLIO"
  }, [])
  return (
    <Box display="flex" width="100%" height="auto">
        <Layout>
          <Profile />
        </Layout>
      </Box>
  )
}

export default profile