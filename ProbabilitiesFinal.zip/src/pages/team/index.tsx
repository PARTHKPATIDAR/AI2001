import Team from '@/components/global/Team'
import Layout from '@/components/Layout'
import { Box } from '@mui/material'
import React, { useEffect } from 'react'

const team = () => {
  useEffect(() => {
    document.title = "TEAM | PORTFOLIO"
  }, [])
  return (
    <Box display="flex" width="100%" height="auto">
        <Layout>
          <Team />
        </Layout>
      </Box>
  )
}

export default team