export const  dateFormatter = (date : any) =>{
    let objectDate  = new Date(date)
  
    const formattedDate = String(objectDate.getFullYear())
                          + "-" + String(objectDate.getMonth() + 1).padStart(2,'0') 
                          + "-" + String(objectDate .getDate()).padStart(2,'0') ;

    return formattedDate
}

export const  dateAdvancedFormatter = ({date,advancedDay }: any) =>{
    let objectDate  =  new Date(date)
  
    const formattedDate = String(objectDate.getFullYear())
                          + "-" + String(objectDate.getMonth() + 1).padStart(2,'0') 
                          + "-" + String(objectDate .getDate() + advancedDay).padStart(2,'0') ;
    
    return formattedDate
}